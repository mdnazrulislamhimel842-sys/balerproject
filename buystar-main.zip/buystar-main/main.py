import logging
from FragmentAPI import SyncFragmentAPI
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# ====================== CONFIG ======================
BOT_TOKEN = "8759247275:AAFteL7h4s7HUvAAE0SlvjEvbWoPEBZDI7c"

FRAGMENT_COOKIES = (
    "stel_ssid=bd57e87e8c4b0761f0_5956461133933751228;"
    "stel_token=e1abbaced17a70ed881152034def6042e1abbad4e1abb9dd8559468fc61dc39d44023;"
    "stel_dt=-360;"
    "stel_ton_token=IvDNDqAq_GWtBZLTwUfnhTPEKNsIlmaXmBQW1Xk_QePw1mDt2gtHEGokyU5kl7U6_s9jc1ItJ-8IHca1S4UTnq6GNYeHN9v8OwIrLfBzrw_RcPsuUzyINPVlP3EFbA1imDeeH8GrSU3x8A3WDlbantxj9NZqzKtXC7BxzraUcsMiKPwUbMc1eEq8Fhgo4eRdM2HFX4fc"
)

# ←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←←
FRAGMENT_HASH = "27ca3aa3a589bcee77"   
# ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
# Fragment.com এ গিয়ে F12 → Network → api request থেকে hash কপি করো

WALLET_MNEMONIC = "funny oblige mushroom bread hollow tape base enemy dinosaur genuine smooth enact before venue border cover trigger pluck antenna holiday crack main dance either"
WALLET_API_KEY = "AGDJUWWWYXOIMDAAAAAJYFRJMCPM6ZBTM4YLQDSOGF5FRQPSYODUVBAIIHRRQJGIOBFDJ7Y"
# ====================================================

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# =============== Initialize Fragment API ===============
try:
    api = SyncFragmentAPI(
        cookies=FRAGMENT_COOKIES,
        hash_value=FRAGMENT_HASH,
        wallet_mnemonic=WALLET_MNEMONIC,
        wallet_api_key=WALLET_API_KEY,
        timeout=30
    )
    print("✅ Fragment API successfully initialized!")
except Exception as e:
    print(f"❌ API Initialization Failed: {e}")

# ====================== Commands ======================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚀 **Bot is Ready!**\n\n"
        "Available Commands:\n"
        "/balance → Check your TON wallet balance\n"
        "/stars username amount → Send Telegram Stars\n\n"
        "Example:\n`/stars durov 50`"
    )

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        await update.message.reply_text("🔄 Checking your TON wallet balance...")

        bal = api.get_wallet_balance()          # Correct method

        ton_balance = bal.get('balance_ton', 0)
        address = bal.get('address', 'Not found')

        text = f"""
💰 **Wallet Balance**

**TON:** `{ton_balance}`

**Wallet Address:**
`{address}`
        """
        await update.message.reply_text(text)

    except Exception as e:
        error = str(e).lower()
        if "access denied" in error or "hash" in error or "authentication" in error:
            await update.message.reply_text(
                "❌ **Access Denied**\n\n"
                "→ নতুন Hash নিয়ে আবার চেষ্টা করো\n"
                "Fragment.com এ লগইন করে F12 → Network থেকে hash কপি করো"
            )
        else:
            await update.message.reply_text(f"⚠️ Error: {str(e)}")

async def stars(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        if len(context.args) < 2:
            return await update.message.reply_text("❌ Usage: `/stars username amount`")

        username = context.args[0]
        amount = int(context.args[1])

        await update.message.reply_text(f"⏳ Sending {amount} Stars to @{username}...")

        result = api.buy_stars(username, amount)

        if result.success:
            await update.message.reply_text(f"✅ Successfully sent **{amount} Stars** to @{username}!")
        else:
            await update.message.reply_text(f"❌ Failed!\nReason: {result.error}")

    except Exception as e:
        await update.message.reply_text(f"⚠️ Error: {str(e)}")

# ====================== Run Bot ======================
if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("balance", balance))
    app.add_handler(CommandHandler("stars", stars))

    print("🤖 Bot is running... (Update FRAGMENT_HASH first!)")
    app.run_polling(drop_pending_updates=True)
